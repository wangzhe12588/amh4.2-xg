<div id="footer" style="">

当前内存限制 ( 每次处理文件大小限制范围 ) <b> <?php echo $memory_limit;?> </b> <a href="./index.php?c=index&a=rmtmp" >清除缓存</a><br />
Copyright © 2015 华的科技 <a href="https://amh.sh" target="_blank">amh.sh</a> 
All Rights Reserved AMFTP 2.5  <a href="./index.php?c=index&a=help" >使用帮助</a>
<br />
<br />
</div>

</body>
</html>