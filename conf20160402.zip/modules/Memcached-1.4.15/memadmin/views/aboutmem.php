<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Mem_About</title>
<style type="text/css">
body{font:'Courier New',Arial,sans-serif;font-size:14px;}
a{color:#0066cc;}
#showabout{margin-left:10px;margin-top:20px;}
#homepage{margin-top:20px;}
#email{margin-top:20px;}
</style>
</head>
<body>
<div id="showabout">
<div id="abtit">MemAdmin -- 基于PHP5+JQuery的可视化Memcached管理/监控工具，主要用于开发、维护阶段的调试和性能监控。</div>
<div id="homepage">获得最新版本：<a href="http://www.junopen.com/memadmin" target="_blank">http://www.junopen.com/memadmin</a></div>
<div id="email">BUG提交与反馈：junstor@gmail.com</div>
</div>
</body>
</html>