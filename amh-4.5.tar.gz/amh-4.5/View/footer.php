<?php !defined('_Amysql') && exit; ?>

<div id="footer">
©2013 专注于LNMP / Nginx 平台架构开发
</div>
</body>
</html>