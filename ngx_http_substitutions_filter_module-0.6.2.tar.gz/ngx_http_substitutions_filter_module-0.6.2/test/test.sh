#!/bin/sh

#TEST_NGINX_BACKENDS_PORT=127.0.0.1:1234 PATH=/home/yaoweibin/nginx/sbin:$PATH prove -r t

PATH=/home/yaoweibin/nginx/sbin:$PATH prove -r t
